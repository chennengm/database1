select *from t_user where id='1001'and psw='1'


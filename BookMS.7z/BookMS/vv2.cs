﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookMS
{
    public partial class vv2 : Form
    {
        public vv2()
        {
            InitializeComponent();
            this.BackgroundImage = BookMS.Properties.Resources.p33;
            table();
        }

        private void vv2_Load(object sender, EventArgs e)
        {

        }
        public void table()
        {
            
                dataGridView2.Rows.Clear(); // 清空旧数据
                Dao dao = new Dao();

                string sql = $"select [no1],[bid1],[name],[dt],[ud],[psw] from vjy where ud='{v1.idd}'";
               // Console.WriteLine("Executing SQL: " + v1.idd); // 输出 SQL 语句

                IDataReader dc = dao.read(sql);
                while (dc.Read())
                {
                    dataGridView2.Rows.Add(dc[0].ToString(), dc[1].ToString(), dc[2].ToString(),dc[3].ToString(), dc[4].ToString(), dc[5].ToString());
                }
                dc.Close();
                dao.DaoClose();
            
        }
    }
}

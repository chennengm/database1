﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookMS
{
    public partial class admin22 : Form
    {
        string ID ="";
        public admin22()
        {
            InitializeComponent();
            this.BackgroundImage = BookMS.Properties.Resources.p33;
        }
        public admin22(string id,string name,string author,string press,string number)
        {
            InitializeComponent();
            
            this.BackgroundImage = BookMS.Properties.Resources.p33;
            //string oid = id;
            ID =textBox1.Text = id; 
            textBox2.Text = name;
            textBox3.Text = author;
            textBox4.Text = press;
            textBox5.Text = number;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sql = $"EXEC gx" +
             $"    @oldId = '{ID}', " +
             $"    @newId = '{textBox1.Text}', " +
             $"    @name = '{textBox2.Text}', " +
             $"    @author = '{textBox3.Text}', " +
             $"    @press = '{textBox4.Text}', " +
             $"    @number = '{textBox5.Text}'";

            Console.WriteLine(sql);
            Dao dao = new Dao();
            int rowsAffected = dao.Execute(sql);
            if (rowsAffected <=0)
            {
                MessageBox.Show("修改成功");
                this.Close();
            }

        }

        private void admin22_Load(object sender, EventArgs e)
        {

        }
    }
}

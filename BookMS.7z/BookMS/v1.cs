﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookMS
{  
    public partial class v1 : Form
    {
       public static  string idd = "";
         
        public v1()
        {
            InitializeComponent();
            table();
            this.BackgroundImage = BookMS.Properties.Resources.p33;
            
        }
        public void table()
        {
            dataGridView1.Rows.Clear();//清空旧数据
            Dao dao = new Dao();
            string sql = $"select [id],[name],[sex],[psw],[uadmin] from t_user ";
            IDataReader dc = dao.read(sql);
            while (dc.Read())
            {
                dataGridView1.Rows.Add(dc[0].ToString(), dc[1].ToString(), dc[2].ToString(), dc[3].ToString(), dc[4].ToString());
            }
            dc.Close();
            dao.DaoClose();
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void v1_Load(object sender, EventArgs e)
        {
            table();
            label2.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString() + dataGridView1.SelectedRows[0].Cells[1].Value.ToString();//获取用户
        }
       

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_Click_1(object sender, EventArgs e)
        {
            label2.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString() + dataGridView1.SelectedRows[0].Cells[1].Value.ToString();//获取用户
            idd = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            Console.WriteLine("Executing SQL: " + v1.idd); // 输出 SQL 语句
        }

        private void b1_Click(object sender, EventArgs e)
        {
            vv2 v2 = new vv2();
            v2.ShowDialog();

            //dataGridView1.Rows.Clear();//清空旧数据
            //Dao dao = new Dao();
            //string sql = $"select [no],[bid],[datatime] from t_lend where uid='{idd}'";
            //IDataReader dc = dao.read(sql);
            //while (dc.Read())
            //{
            //    dataGridView1.Rows.Add(dc[0].ToString(), dc[1].ToString(), dc[2].ToString());
            //}
            //dc.Close();
            //dao.DaoClose();
            table();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookMS
{
    public partial class user1 : Form
    {
        public user1()
        {
            InitializeComponent();
            this.BackgroundImage = BookMS.Properties.Resources.p11;
        }

        private void 图书查看和借阅ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            user2 u = new user2();
            u.ShowDialog();
        }

        private void 我的图书ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            user3 user3 = new user3();
            user3.ShowDialog(); 
        }

     

        private void 系统ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void 联系管理员ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("<果：（wx）g1351274589");
        }

       

       

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void user1_Load(object sender, EventArgs e)
        {

        }

        private void 帮助ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("help鼠鼠大作业");
        }

        private void 退出ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookMS
{
    public partial class admin1 : Form
    {
        public admin1()
        {
            InitializeComponent();
            this.BackgroundImage = BookMS.Properties.Resources.p11;
        }

        private void 图书管理ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            admin2 admin=new admin2();
            admin.ShowDialog();
        }

        private void admin1_Load(object sender, EventArgs e)
        {

        }

        private void 退出ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();   
        }

        private void 帮助ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("help鼠鼠大作业");
        }

        private void 用户管理ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            v1 ad = new v1();
            ad.ShowDialog();
        }
    }
}

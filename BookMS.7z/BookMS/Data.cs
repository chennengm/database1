﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookMS
{
    class Data
    {
        public static string UID = "", UName = "";//登录用户的id和姓名
    }
}

﻿using BookMS.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookMS
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
            //这里的图片的路径需要使用绝对路径
            this.BackgroundImage = BookMS.Properties.Resources.p22;


        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
        
        private void button1_Click_1(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "")
            {
                Login();
            }
            else
            {
                MessageBox.Show("用户名或密码不能为空，请重新输入");
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        //登录方法，验证是否允许登录，允许返回真
        public void Login()
        {//用户
            if (radioButtonUser.Checked == true)
            {
                Dao dao = new Dao();
                string sql = $"select *from t_user where id='{textBox1.Text}'and psw='{textBox2.Text}'";
                //MessageBox.Show(sql);
                IDataReader dc=dao.read(sql);
               if(dc.Read())
                {
                    Data.UID = dc["id"].ToString(); 
                    Data.UName=dc["name"].ToString();

                    MessageBox.Show("登陆成功");
                    user1 user = new user1();//实例化用户窗体
                    this.Hide();
                    user.ShowDialog();//关闭窗体操作
                    this.Show();

                  
                }
               else
                {
                    MessageBox.Show("登录失败,请检查账号密码是否输入正确");
                    
                }
                dao.DaoClose();
                //MessageBox.Show(dc[0].ToString()+dc["name"].ToString());
            }
            //管理员
            if (radioButtonAdm.Checked == true)
            {
                Dao dao = new Dao();
                string sql = $"select *from t_admin where id='{textBox1.Text}'and psw='{textBox2.Text}'";
                //MessageBox.Show(sql);
                IDataReader dc = dao.read(sql);
                if (dc.Read())
                {
                    MessageBox.Show("登陆成功");
                    admin1 a=new admin1();  
                    this.Hide();
                    a.ShowDialog();
                    this.Show();
                   
                }
                else
                {
                    MessageBox.Show("登录失败");
                    
                }
                dao.DaoClose();
            }
         
        

        }

        private void login_Load(object sender, EventArgs e)
        {

        }
    }
}
